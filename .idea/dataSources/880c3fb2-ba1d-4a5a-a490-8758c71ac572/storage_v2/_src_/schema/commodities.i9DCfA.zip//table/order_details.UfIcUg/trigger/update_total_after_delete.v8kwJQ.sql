create definer = root@localhost trigger update_total_after_delete
    after delete
    on order_details
    for each row
BEGIN
    UPDATE orders 
    SET total_amount = total_amount - OLD.quantity * OLD.price
    WHERE orderid = OLD.orderid;
END;

