create definer = root@localhost trigger update_total_after_update
    after update
    on order_details
    for each row
BEGIN
    DECLARE diff DECIMAL(10,2);
    SET diff = (NEW.quantity * NEW.price) - (OLD.quantity * OLD.price);
    UPDATE orders 
    SET total_amount = total_amount + diff
    WHERE orderid = NEW.orderid;
END;

