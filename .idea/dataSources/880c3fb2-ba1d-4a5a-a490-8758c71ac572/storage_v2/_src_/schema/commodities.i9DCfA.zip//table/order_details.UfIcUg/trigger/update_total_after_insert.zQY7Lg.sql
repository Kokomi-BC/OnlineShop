create definer = root@localhost trigger update_total_after_insert
    after insert
    on order_details
    for each row
BEGIN
    UPDATE orders 
    SET total_amount = total_amount + NEW.quantity * NEW.price
    WHERE orderid = NEW.orderid;
END;

